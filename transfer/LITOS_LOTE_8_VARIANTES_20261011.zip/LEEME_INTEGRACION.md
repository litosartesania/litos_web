# LITOS | Lote de 8 nuevas variantes — 11 octubre 2026

Este paquete contiene SOLO ocho imágenes reenviadas por el propietario y su manifiesto de integridad. Se ha cambiado el **nombre de fichero de destino**, pero **nunca los bytes PNG originales**. SHA-256 y tamaño figuran en `docs/LOTE_8_IMAGENES_20261011.json`.

## Objetivo

- Consola escultórica `consola-esc`: `caliza`, `carrara`, `cuarcita`, `calacatta`.
- Banco escultórico `banco-esc`: `caliza`, `carrara`, `cuarcita`, `calacatta`.

La clasificación por material es la variante conceptual generada, no una certificación geológica de las propiedades de una piedra real. No son obras físicas ejecutadas ni productos vendidos por LITOS.

## Integración segura pendiente

1. Crear una **nueva rama aislada** a partir de `main` del repositorio exclusivo `litosartesania/litos_web`; no modificar otros repositorios.
2. Importar los 8 archivos bajo `assets/catalogo/variantes/` sin regenerarlos, redimensionarlos, recolorearlos ni recomprimirlos. No sustituir los 10 PNG ya publicados.
3. Ampliar `approvedVariants` en `catalogo-precios.js` con 8 combinaciones producto/piedra, conservando los demás modelos, filtros, los nueve materiales y precios orientativos. Invalidar caché JS/CSS solo si se modifica código.
4. Ampliar allowlist, manifiestos de integridad y tests de build (`scripts/build-site.sh`, `scripts/check-site.py`, pruebas de Playwright, verificación HTTP postdespliegue) de 10 a 18 archivos, conservando el guard de privacidad. El límite actual de paquete de 40 MB no admite 18 imágenes (no subirlo arbitrariamente: adaptar el límite al tamaño exacto de los PNG autorizados + margen pequeño para assets).
5. Validar local / GitHub Actions en rama y generar vista previa navegable. **No desplegar en GitHub Pages sin revisión y autorización del usuario**.
6. Una vez autorizada la publicación: fusionar PR aprobado y verificar en la URL pública HTTP 200 y SHA-256 de **18/18** PNG, así como selector 2×9 en tres tamaños de pantalla.

## Estado actual

8/8 imágenes catalogadas y verificadas en el paquete local. Aún **no publicadas**. El lote anterior: 10/10 publicado y verificado.
